const pool = require('../config/database');
const User = require('../models/User');
const Address = require('../models/Address');
const Geo = require('../models/Geo');
const Company = require('../models/Company');

class UserService {
    async getAllUsers() {
        const query = `
            SELECT u.id as user_id, u.name as user_name, u.username as user_username, 
            u.email as user_email, u.phone as user_phone, u.website as user_website,
            a.id as address_id, a.street as address_street, a.suite as address_suite, a.city as address_city, a.zipcode as address_zipcode,
            g.id as geo_id, g.lat as geo_lat, g.lng as geo_lng,
            c.id as company_id, c.name as company_name, c.catch_phrase as company_catch_phrase, c.bs as company_bs
            FROM users u LEFT JOIN address a ON u.address_id = a.id LEFT JOIN geo g ON a.geo_id = g.id LEFT JOIN company c ON u.company_id = c.id ORDER BY u.id`;
        const [rows] = await pool.execute(query);
        return rows.map(row => User.fromDbRow(row));
    }

    async getUserById(id) {
        const query = `
            SELECT u.id as user_id, u.name as user_name, u.username as user_username, 
            u.email as user_email, u.phone as user_phone, u.website as user_website,
            a.id as address_id, a.street as address_street, a.suite as address_suite, a.city as address_city, a.zipcode as address_zipcode,
            g.id as geo_id, g.lat as geo_lat, g.lng as geo_lng,
            c.id as company_id, c.name as company_name, c.catch_phrase as company_catch_phrase, c.bs as company_bs
            FROM users u LEFT JOIN address a ON u.address_id = a.id LEFT JOIN geo g ON a.geo_id = g.id LEFT JOIN company c ON u.company_id = c.id WHERE u.id = ?`;
        const [rows] = await pool.execute(query, [id]);
        return rows.length > 0 ? User.fromDbRow(rows[0]) : null;
    }

    async existsByUsername(username) {
        const [rows] = await pool.execute('SELECT COUNT(*) as count FROM users WHERE username = ?', [username]);
        return rows[0].count > 0;
    }

    async existsByEmail(email) {
        const [rows] = await pool.execute('SELECT COUNT(*) as count FROM users WHERE email = ?', [email]);
        return rows[0].count > 0;
    }

    async createUser(userData) {
        const connection = await pool.getConnection();
        try {
            await connection.beginTransaction();
            if (await this.existsByUsername(userData.username)) throw new Error('Username already exists');
            if (await this.existsByEmail(userData.email)) throw new Error('Email already exists');

            let geoId = null, addressId = null, companyId = null;

            if (userData.address && userData.address.geo) {
                const geo = new Geo(userData.address.geo).toDbValues();
                const [res] = await connection.execute('INSERT INTO geo (lat, lng) VALUES (?, ?)', [geo.lat, geo.lng]);
                geoId = res.insertId;
            }
            if (userData.address) {
                const addr = new Address(userData.address).toDbValues();
                const [res] = await connection.execute('INSERT INTO address (street, suite, city, zipcode, geo_id) VALUES (?, ?, ?, ?, ?)', [addr.street, addr.suite, addr.city, addr.zipcode, geoId]);
                addressId = res.insertId;
            }
            if (userData.company) {
                const comp = new Company(userData.company).toDbValues();
                const [res] = await connection.execute('INSERT INTO company (name, catch_phrase, bs) VALUES (?, ?, ?)', [comp.name, comp.catch_phrase, comp.bs]);
                companyId = res.insertId;
            }

            const user = new User(userData).toDbValues();
            const [userRes] = await connection.execute('INSERT INTO users (name, username, email, phone, website, address_id, company_id) VALUES (?, ?, ?, ?, ?, ?, ?)', [user.name, user.username, user.email, user.phone, user.website, addressId, companyId]);
            
            await connection.commit();
            return await this.getUserById(userRes.insertId);
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    }

    async updateUser(id, userData) {
        const connection = await pool.getConnection();
        try {
            await connection.beginTransaction();
            const existingUser = await this.getUserById(id);
            if (!existingUser) throw new Error('User not found');

            const user = new User(userData).toDbValues();
            await connection.execute('UPDATE users SET name = ?, username = ?, email = ?, phone = ?, website = ? WHERE id = ?', 
                [user.name || existingUser.name, user.username || existingUser.username, user.email || existingUser.email, 
                 user.phone !== undefined ? user.phone : existingUser.phone, user.website !== undefined ? user.website : existingUser.website, id]);

            await connection.commit();
            return await this.getUserById(id);
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    }

    async deleteUser(id) {
        const connection = await pool.getConnection();
        try {
            await connection.beginTransaction();
            const user = await this.getUserById(id);
            if (!user) throw new Error('User not found');

            await connection.execute('DELETE FROM users WHERE id = ?', [id]);
            if (user.address) {
                if (user.address.geo) await connection.execute('DELETE FROM geo WHERE id = ?', [user.address.geo.id]);
                await connection.execute('DELETE FROM address WHERE id = ?', [user.address.id]);
            }
            if (user.company) await connection.execute('DELETE FROM company WHERE id = ?', [user.company.id]);

            await connection.commit();
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    }
}
module.exports = new UserService();