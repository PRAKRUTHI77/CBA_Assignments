const userService = require('../services/UserService');
const { validationResult } = require('express-validator');

class UserController {
    async getAllUsers(req, res) {
        try { res.status(200).json(await userService.getAllUsers()); } 
        catch (error) { res.status(500).json({ message: error.message }); }
    }
    async getUserById(req, res) {
        try {
            const user = await userService.getUserById(parseInt(req.params.id));
            user ? res.status(200).json(user) : res.status(404).json({ message: 'User not found' });
        } catch (error) { res.status(500).json({ message: error.message }); }
    }
    async createUser(req, res) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
            res.status(201).json(await userService.createUser(req.body));
        } catch (error) { res.status(400).json({ message: error.message }); }
    }
    async updateUser(req, res) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
            const user = await userService.updateUser(parseInt(req.params.id), req.body);
            user ? res.status(200).json(user) : res.status(404).json({ message: 'User not found' });
        } catch (error) { res.status(400).json({ message: error.message }); }
    }
    async deleteUser(req, res) {
        try {
            await userService.deleteUser(parseInt(req.params.id));
            res.status(200).json({ message: 'User deleted successfully' });
        } catch (error) { res.status(500).json({ message: error.message }); }
    }
}
module.exports = new UserController();