import axios from 'axios';

export const getApiBaseUrl = () => {
  return 'http://localhost:5000/api/users';
};

export const apiClient = axios.create({
  timeout: 10000, 
  headers: { 'Content-Type': 'application/json' }
});

apiClient.interceptors.request.use((config) => {
    config.baseURL = getApiBaseUrl();
    return config;
}, (error) => Promise.reject(error));

apiClient.interceptors.response.use((response) => response, (error) => Promise.reject(error));