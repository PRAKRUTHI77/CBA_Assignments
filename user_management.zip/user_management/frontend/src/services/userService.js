import { apiClient } from '../utils/apiConfig';

const userService = {
  getAllUsers: async () => (await apiClient.get('')).data,
  getUserById: async (id) => (await apiClient.get(`/${id}`)).data,
  createUser: async (userData) => (await apiClient.post('', userData)).data,
  updateUser: async (id, userData) => (await apiClient.put(`/${id}`, userData)).data,
  deleteUser: async (id) => (await apiClient.delete(`/${id}`)).data
};

export default userService;